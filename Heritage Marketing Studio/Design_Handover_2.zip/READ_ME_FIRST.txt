The Marketing Studio - handover 2
=================================

app.dc.html is NOT in this zip. It is byte-identical to the one you sent, so
keep working in your copy - nothing was changed in it this round.

1. DESIGN_NEXT.md      START HERE. 9KB. Only what is new:
                         S11  a contract I got wrong and have fixed. No work
                              for you - your option cards were right all along.
                         S12  the one new screen: Studio Settings, brand and
                              category. This is the ask.

2. DESIGN.md           The full living document, 37KB. Unchanged apart from the
                       two sections above. Reference it, do not re-read it.
                       Section 8 is the do-not-undo list - 16 items.

3. sample_brands.json  The four brand profiles already on the server, filled in:
                       dairy, apparel, beauty, cement. Design against these
                       rather than lorem - they are what the screen must hold.
                       'voice' shows the exact text each one sends to the model.

The short version of the ask: everything the studio generates is now grounded in a
brand profile, and the profile has no screen. Four exist; switching them needs a
curl. Section 12 has the fields, grouped, each with a line on what it buys.

The one field that matters most is category_axis - what the category competes on.
Purity for milk, consistent strength for cement, fit and fabric for apparel. Get
that captured and the studio adapts to the category. Miss it and every output is
competent and generic.
