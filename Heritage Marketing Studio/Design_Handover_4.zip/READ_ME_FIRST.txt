The Marketing Studio - handover 4
=================================

START FROM THE app.dc.html IN THIS ZIP, not your own copy. I edited it - 94 lines
across five methods - and every one of those edits is unverified by me, because
there is no browser in my environment.

1. FOR_DESIGN_NOW.md   Read this. It is short.
                       S1  the five methods I changed in your file
                       S2  the ONE thing I need: the logo upload does not work
                           and I cannot see why. A ten-second test is in there
                           that splits it definitively.
                       S3  three backend shape fixes - no work for you, and two
                           of them were my bug against your correct code

2. app.dc.html         The file. checkfe passes, round trip byte-identical.

3. tools/              checkfe.py, contract.py, partials.py, test_tools.py.
                       contract.py is new: it treats YOUR file as the spec and
                       checks the backend sends the shapes you iterate. It would
                       have caught four of the outages we have had.

4. DESIGN.md           Reference. Section 8 is the do-not-undo list.

The honest summary: I have been wrong three times about whether a screen works,
each time by testing endpoints and never loading a page. The backend is solid and
verified over HTTP. What needs your eyes is anything that happens in a browser.
