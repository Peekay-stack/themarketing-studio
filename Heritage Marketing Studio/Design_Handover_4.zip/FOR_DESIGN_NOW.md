# For Claude Design — what I changed in your file, and the one thing I need

**The file in this folder is the one to work from**, not your last copy. I edited it, and I could not run
it — there is no browser in my environment, so anything I changed in `app.dc.html` is unverified by me.
Two of the four changes below are working (a person clicked them). One is not, and I cannot tell you why.

`checkfe` passes, the round trip is byte-identical, 17/17 tool tests, and the backend is verified over
real HTTP. None of that proves a click works, which is exactly the gap.

---

## 1. What I changed in `app.dc.html` — 94 lines, five methods

I would rather you owned all of this. I only touched it because it was blocking testing.

| Method | What I did | State |
|---|---|---|
| `uploadClientLogo` | Rewrote it to POST `/brand-logo` instead of making a `blob:` URL | **NOT WORKING — see §2** |
| `clearClientLogo` | Now also POSTs `/brand-logo-clear` so the logo goes server-side too | untested |
| `syncBrandLogo()` | **New.** Reads the logo off the active brand profile. Called from the `loadBrands` callback and from `switchBrand` | untested |
| `saveStudio` | Also syncs `{client_name, accent, theme}` to `POST /studio-settings`, fire-and-forget | untested |
| `componentDidMount` | Calls `loadStudioServer()`, and **discards any stored `blob:` logo** on load | untested |

Why the blob URL had to go: it lives in one tab and dies with it, but the *string* persisted in
`localStorage` — so the next visit rendered a **broken image** rather than none, which reads as lost work.

## 2. The one thing I need: the logo upload does not work and I cannot see why

A person clicks *⬆ Upload a logo* in Studio settings and nothing happens.

**What I have ruled out:**

- `POST /brand-logo` works. Verified over real HTTP: `200 OK`, 13,460-byte JSON, the file stored, served
  back byte-identical as `image/svg+xml`, surviving a server restart. It also correctly rejects a `.txt`
  (400) and anything over 4MB (413).
- `uploadClientLogo` **is** exposed in the bag — `uploadClientLogo:this.uploadClientLogo`.
- The input is wired: `<input type="file" accept="image/*" onChange="{{ uploadClientLogo }}">`, one only.
- Everything the handler calls exists: `activeBrand()`, `showToast`, `setStudio`, `saveStudio`, and
  `state.brands` is initialised to `[]` and filled by `loadBrands()` on mount.

**What I cannot rule out**, and where I would look first:

1. Does the handler fire at all? An `async` arrow bound through `onChange="{{ }}"` may not be handled the
   way a sync one is in this templating — that is the change I made and the thing I cannot test.
2. `this.activeBrand()` returning null would show a toast — *"Pick a brand first"*. If that toast appears,
   the brands list is empty at click time and the fix is ordering, not the upload.
3. `e.target.value = ''` runs before the `await`. If clearing the input invalidates the `File` in the
   host's environment, `fd` carries nothing.

**The definitive split takes ten seconds.** Run the server with `--log-level info`, click Upload, and look:

- a `POST /brand-logo` line in the log → the handler fires and the problem is display or state
- **nothing** in the log → the handler never runs, and it is (1) or (2)

If you would rather rewrite the handler your way against the contract below, please do — you will get it
right faster than I will guess.

### The contract

```
POST /brand-logo          multipart: brand=<brand id>, file=<the image>
  200 -> { brand:{…, logo, voice}, brands:[…all, with logo…], logo:"/brand-logo/<id>", bytes:n }
  400  not an image / empty · 404 no such brand · 413 over 4MB — `detail` is a sentence to show
GET  /brand-logo/{id}     the image, correct content-type. 404 when there is none
POST /brand-logo-clear    { brand:<id> } -> { brand, brands }
GET  /studio-settings     -> { settings:{ client_name, accent, theme, manager_name } }
POST /studio-settings     any subset of those keys -> { settings }
```

`/brands` now carries `logo` on each brand, so `syncBrandLogo()` needs no extra call.

## 3. Three backend shape fixes since your last build — no work for you

All three were mine. Each was a blank screen or a crash, and each is now covered by a test.

- **`status.layers[].asks` is an array**, not a string. Your `(L.asks || []).map(…)` was correct; I sent
  prose and whitescreened the app. It is now sentence-split, so *"What this layer has to answer"* renders
  as the checklist you designed. `asks_text` holds the prose.
- **`status.layers[]` carries `layer`, `key` and `name`** alongside `id`. Your
  `ls.find(x => (x.layer || x.name || x.key) === key)` was resolving `null` for **every layer of every
  house and plan** — nothing could render and no click could resolve. Also correct on your side.
- **Generation is reliable now.** All eight generators went through one fragile JSON parser that broke on a
  trailing sentence, a mid-line fence or a trailing comma. *"Offer options for this layer"* genuinely did
  nothing, intermittently. There is now one extractor that scans for the outermost balanced object, plus
  one retry.

`tools/contract.py` now treats your file as the specification: wherever you do `(x.field || []).map`, the
backend must send a list; wherever you find a row by a set of names, every row must carry one. It catches
all four of these if reintroduced, and runs inside `test_tools.py`.

## 4. Still yours, from DESIGN_NEXT §12

Unchanged asks, when you have budget:

1. **The Studio Settings brand form.** I will have the seven fields and `status.readiness` on the backend
   shortly — the questions are: what the category competes on · what you can prove and what proves it ·
   your regulator and banned words · purchase cycle and decider/payer/user · your real channels · the
   cheap alternative you lose to · price tier. Eight further fields are **derivable** from the brief and
   the house, so the form should pre-fill and let someone correct rather than ask twice.
2. **Echo `source` into `/idea-platform`** — you get `source:"model"` from `/idea-draft` and currently drop
   it, so an unedited drafted line adopts as the author's.
3. **The live-action shots screen** — seven routes still have no UI.

## 5. How to check yourself before sending

```bash
python tools/checkfe.py       # syntax, pairing, duplicate members, bag spread
python tools/contract.py      # backend shapes vs what you iterate
python tools/test_tools.py    # 17 tests, includes both of the above
```

I have been wrong three times in a row about whether a screen works, always by testing endpoints and never
loading a page. If a check here passes and the screen is still broken, the check is what needs fixing —
tell me and I will fix the check rather than the symptom.
