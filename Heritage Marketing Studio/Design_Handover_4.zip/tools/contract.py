#!/usr/bin/env python
"""contract.py — does the backend send the shape the frontend reads?

Four separate outages came from one mistake made four times: a field whose name the two sides agreed on
and whose *shape* they did not.

    status.layers[].options   sent as a count      read as an array   -> nothing rendered, ever
    status.layers[].rows      sent as a count      read as an array   -> empty tables
    status.layers[].id        sent as `id` only    read as `layer`    -> every layer resolved to null
    status.layers[].asks      sent as a string     read as an array   -> `.map is not a function`, whitescreen

Each was found by a person clicking, after being shipped. None was caught by `checkfe` (which reads
syntax, not meaning) or by the endpoint diff (which reads paths, not payloads). This is the missing check.

It works by treating the frontend as the specification. Wherever the client does `(X.field || []).map(…)`
or `(X.field || []).length`, it is asserting that `field` is a list. This builds a real house, plan and
platform, then verifies every such field really is one.

    python tools/contract.py

It cannot catch everything — a field read as a string but sent as a number will pass. What it does catch
is the exact class that has actually broken this app, which is where a check earns its keep.
"""
from __future__ import annotations

import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
API = os.path.join(ROOT, "api")
FE = os.path.join(API, "frontend", "app.dc.html")

# Scoped deliberately to `status.layers[]`, because that is where every outage happened and because a
# broader scan produced only noise: `added` on an option is a timestamp, but `(d.added||[]).length` in the
# library-upload response is a list, and a name-matching check flags the first because of the second.
#
# A check that reports six phantom problems and no real ones is worse than no check — the next genuine
# failure arrives in a list somebody has learnt to skim. So this asks one precise question instead:
# for the layer rows the house and plan screens read, does every field they iterate come back iterable,
# and does every row carry a name they can identify it by?
#
# `LAYER_LIST_FIELDS` is derived from the client rather than hardcoded: any `(x.field || []).map` where
# the same field name also exists on a layer row counts.
IDENT_READ = re.compile(r"\.find\(\s*\w+\s*=>\s*\(([^)]+)\)\s*===")
LIST_READ = re.compile(r"\(\s*(?:[A-Za-z_$][\w$]*\.)*([A-Za-z_$][\w$]*)\s*\|\|\s*\[\]\s*\)\s*\.\s*(map|length|find|filter|forEach|slice|indexOf|join)")


def frontend_expectations() -> tuple[set[str], list[set[str]]]:
    src = open(FE, encoding="utf-8").read()
    lists = {m.group(1) for m in LIST_READ.finditer(src)}
    idents = []
    for m in IDENT_READ.finditer(src):
        names = {n.strip().split(".")[-1] for n in m.group(1).split("||") if n.strip()}
        if names:
            idents.append(names)
    return lists, idents


def build_samples() -> dict:
    """One of every status payload, with enough content that empty collections do not hide a bug."""
    sys.path.insert(0, API)
    os.environ["STUDIO_TENANT"] = "contractcheck"
    import shutil
    import tenancy
    shutil.rmtree(os.path.join(tenancy.TENANTS, "contractcheck"), ignore_errors=True)
    import importlib
    for m in ("tenancy", "brandprofile", "briefstore", "strategy", "plan", "ideas",
              "sales", "execution", "shotlist", "findings"):
        importlib.reload(importlib.import_module(m))
    import strategy, plan, ideas, sales, shotlist, brandprofile
    brandprofile.seed()

    h = strategy.new_house("Contract Co", {"smp": "a proposition"})
    for layer in ("core", "emotional", "functional", "rtb_functional"):
        h = strategy.add_option(h, layer, f"an option for {layer}", note="why")
        h = strategy.choose(h, layer, [h["nodes"][layer]["options"][0]["id"]])
    h = strategy.add_option(h, "culture", "an occasion", tag="occasion")
    h = strategy.choose(h, "culture", [h["nodes"]["culture"]["options"][0]["id"]])

    p = plan.new_plan("Contract Co", h["id"])
    p = plan.add_row(p, "objectives", {"level": "business", "statement": "grow", "measure": "+1%",
                                       "by_when": "FY27"})
    p = plan.add_row(p, "audiences", {"audience": "someone", "rank": "1",
                                      "believes_now": "something", "pillar": "functional"})

    pl = ideas.new_set("Contract Co", h["id"])
    pl = ideas.adopt(pl, {"name": "A platform", "line": "one sentence",
                          "tests": {"true": {"verdict": "holds", "note": "n"}},
                          "routes": {"social": "a", "posm": "b"}})

    sh = sales.new_sheet("Contract Co")
    sh = sales.set_channel(sh, "trad", {"role": "volume", "share_now": "60",
                                        "behaviour": "order weekly", "baseline": "1", "target": "2",
                                        "lever": "trade scheme", "payback": "payback unknown",
                                        "leakage": "loading", "control": "cap on rate of sale",
                                        "residual_risk": "diversion", "receives_money": "retailer",
                                        "sell_through": "secondary", "effective_price": "56"})
    sl = shotlist.for_execution("")
    sl["shots"] = shotlist.plan_from([{"no": 1, "visual": "a shot", "title": "One"}], None)
    sl = shotlist.save(sl)

    out = {
        "house": strategy.status(h),
        "plan": plan.status(p, h),
        "platform": ideas.status(pl, h),
        "trade": sales.status(sh, h),
        "shotlist": shotlist.status(sl),
    }
    shutil.rmtree(os.path.join(tenancy.TENANTS, "contractcheck"), ignore_errors=True)
    return out


def walk(node, path=""):
    """Every (key, value) in the payload, with the path that reached it."""
    if isinstance(node, dict):
        for k, v in node.items():
            yield path, k, v
            yield from walk(v, f"{path}.{k}" if path else k)
    elif isinstance(node, list):
        for i, v in enumerate(node[:1]):          # one row is enough to type a collection
            yield from walk(v, f"{path}[]")


def main() -> int:
    lists, idents = frontend_expectations()
    samples = build_samples()
    problems, checked = [], 0

    for doc, payload in samples.items():
        rows = (payload.get("layers") or [])
        if not rows or not isinstance(rows, list):
            continue
        row = rows[0]

        # 1. every layer field the client iterates must be iterable
        for key, value in row.items():
            if key not in lists:
                continue
            checked += 1
            if not isinstance(value, (list, tuple)):
                problems.append(
                    f"{doc}: status.layers[].{key} is {type(value).__name__}, but the client does "
                    f"({key} || []).map/.length on a layer — it must be a list")

        # 2. every layer must carry a name the client can find it by
        for names in idents:
            checked += 1
            if not (names & set(row)):
                problems.append(
                    f"{doc}: status.layers[] carries none of {sorted(names)} — the client finds a layer "
                    f"by those names and would resolve null for all of them")

    print(f"the client iterates {len(lists)} field names and identifies rows {len(idents)} way(s); "
          f"{checked} layer-shape checks run on {len(samples)} documents\n")
    if problems:
        for p in sorted(set(problems)):
            print(f"  MISMATCH  {p}")
        print(f"\n{len(set(problems))} shape mismatch(es). Each one is a blank screen or a crash.")
        return 1
    print("  every field the client iterates on a layer is a list, and every layer carries a name it "
          "looks for. (Scoped to status.layers[] — see the note at the top for why.)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
