#!/usr/bin/env python
"""checkfe.py — the check that would have caught the syntax error I shipped.

There is no Node in this environment, so `app.dc.html` cannot be parsed by a real JS engine. Once I
flattened newline escapes and broke eight string literals; the tag-balance and binding checks I was
running all passed, because neither of them looked at JavaScript at all. Claude Design found it.

This is the missing check. It is not a JS parser — it is a scanner that understands just enough lexical
structure to be certain about two things:

**Unterminated string literals.** A `'` or `"` string cannot span a line break in JavaScript. That is
exactly the damage a mangled `\\n` does, and it is the single highest-value check here.

**Bracket balance, ignoring anything quoted or commented.** A naive brace count on this file is
meaningless — the markup is full of `{{ }}` bindings and the logic is full of `${}` inside template
literals. This tracks line comments, block comments, both quote styles, template literals with nested
`${}`, and regex literals, so the count it reports is about code rather than about punctuation.

It also re-runs the structural checks that did work, so one command covers everything:
`sc-if`/`sc-for` pairing, `<div>` pairing, and the class-member census.

    python tools/checkfe.py

Exit code 0 means every check passed. Non-zero lists what failed and on which line. This does not prove
the file runs — nothing here can — but every failure it reports is a real defect, and the failure mode it
was built for is the one that has actually bitten this project.
"""
from __future__ import annotations

import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SRC = os.path.join(ROOT, "api", "frontend", "app.dc.html")

OPEN, CLOSE = "([{", ")]}"
PAIR = {")": "(", "]": "[", "}": "{"}


def _regions(text: str) -> tuple[str, str, int]:
    """(markup, logic, first_logic_line). The logic is the data-dc-script block's body."""
    m = re.search(r"^<script[^>]*data-dc-script[^>]*>$", text, re.M)
    if not m:
        return text, "", 1
    start = text.index("\n", m.end()) + 1
    close = re.search(r"^</script>\s*$", text[start:], re.M)
    end = start + (close.start() if close else len(text) - start)
    return text[:m.start()], text[start:end], text[:start].count("\n") + 1


def scan_js(code: str, first_line: int) -> list[str]:
    """Lexical scan. Returns a list of problems, each naming a line."""
    problems: list[str] = []
    stack: list[tuple[str, int]] = []
    i, line, n = 0, first_line, len(code)
    # Template-literal interpolation nesting. Each entry is the stack DEPTH at which that `${` sits.
    #
    # Depth, not merely a count: `${JSON.stringify({ a:1 })}` contains a brace of its own, and treating
    # the first `}` as the end of the interpolation puts the scanner back into template mode halfway
    # through an expression — which then reports three confident errors in correct code. A lint with
    # false positives is worse than no lint, because the next real one gets waved through too.
    tmpl: list[int] = []
    prev_sig = ""          # last significant char, to tell division from a regex literal

    while i < n:
        c = code[i]
        if c == "\n":
            line += 1
            i += 1
            continue
        # comments
        if c == "/" and i + 1 < n and code[i + 1] == "/":
            i = code.find("\n", i)
            if i < 0:
                break
            continue
        if c == "/" and i + 1 < n and code[i + 1] == "*":
            j = code.find("*/", i + 2)
            if j < 0:
                problems.append(f"line {line}: block comment is never closed")
                break
            line += code.count("\n", i, j)
            i = j + 2
            continue
        # regex literal — only where a value may begin, otherwise it is division
        if c == "/" and prev_sig in "" "(,=:[!&|?{};+-*%~^<>" and prev_sig != "":
            j, cls = i + 1, False
            while j < n and code[j] not in "\n":
                if code[j] == "\\":
                    j += 2
                    continue
                if code[j] == "[":
                    cls = True
                elif code[j] == "]":
                    cls = False
                elif code[j] == "/" and not cls:
                    break
                j += 1
            if j < n and code[j] == "/":
                i = j + 1
                prev_sig = "/"
                continue
        # quoted strings — THE check: these may not cross a line break
        if c in "'\"":
            j = i + 1
            while j < n:
                if code[j] == "\\":
                    j += 2
                    continue
                if code[j] == "\n":
                    problems.append(
                        f"line {line}: unterminated {c!r} string — a quoted string cannot span a line "
                        f"break. This is what a mangled newline escape looks like.")
                    break
                if code[j] == c:
                    break
                j += 1
            if j >= n:
                problems.append(f"line {line}: {c!r} string runs to end of file")
                break
            i = j + 1
            prev_sig = c
            continue
        # template literal
        if c == "`":
            j = i + 1
            while j < n:
                if code[j] == "\\":
                    j += 2
                    continue
                if code[j] == "\n":
                    line += 1
                    j += 1
                    continue
                if code[j] == "$" and j + 1 < n and code[j + 1] == "{":
                    stack.append(("{", line))
                    tmpl.append(len(stack))
                    i = j + 2
                    prev_sig = "{"
                    break
                if code[j] == "`":
                    i = j + 1
                    prev_sig = "`"
                    break
                j += 1
            else:
                problems.append(f"line {line}: template literal runs to end of file")
                break
            continue
        if c in OPEN:
            stack.append((c, line))
        elif c in CLOSE:
            if not stack:
                problems.append(f"line {line}: stray {c!r} — nothing open to close")
            elif stack[-1][0] != PAIR[c]:
                op, ol = stack[-1]
                problems.append(f"line {line}: {c!r} closes {op!r} opened on line {ol}")
                stack.pop()
            else:
                closed_depth = len(stack)
                stack.pop()
                # Only the brace at the interpolation's own depth ends it. Anything deeper is an object
                # literal, a function body or a nested template inside the expression.
                if c == "}" and tmpl and closed_depth == tmpl[-1]:
                    tmpl.pop()
                    j = i + 1
                    while j < n:
                        if code[j] == "\\":
                            j += 2
                            continue
                        if code[j] == "\n":
                            line += 1
                        elif code[j] == "$" and j + 1 < n and code[j + 1] == "{":
                            stack.append(("{", line))
                            tmpl.append(len(stack))
                            j += 1
                            break
                        elif code[j] == "`":
                            break
                        j += 1
                    i = j + 1
                    prev_sig = "`"
                    continue
        if not c.isspace():
            prev_sig = c
        i += 1

    for op, ol in stack:
        problems.append(f"line {ol}: {op!r} is never closed")
    return problems


def check(path: str = SRC) -> int:
    text = open(path, encoding="utf-8").read()
    markup, logic, first = _regions(text)
    fails = 0

    def report(label: str, problems: list[str]) -> None:
        nonlocal fails
        if problems:
            fails += len(problems)
            print(f"  FAIL  {label} — {len(problems)} problem(s)")
            for p in problems[:12]:
                print(f"          {p}")
            if len(problems) > 12:
                print(f"          ... and {len(problems) - 12} more")
        else:
            print(f"  ok    {label}")

    print(f"{os.path.relpath(path, ROOT)} — {len(text):,} bytes, "
          f"{text.count(chr(10)) + 1:,} lines\n")

    report("JavaScript lexical structure", scan_js(logic, first))

    # The structural checks that did work, kept so one command covers everything.
    for tag in ("sc-if", "sc-for"):
        o = len(re.findall(rf"<{tag}[\s>]", markup))
        c = len(re.findall(rf"</{tag}>", markup))
        report(f"<{tag}> pairing ({o} open / {c} close)",
               [] if o == c else [f"{abs(o - c)} unmatched <{tag}>"])
    o, c = markup.count("<div"), markup.count("</div>")
    report(f"<div> pairing ({o} / {c})", [] if o == c else [f"{abs(o - c)} unmatched <div>"])

    members = re.findall(r"^  ([A-Za-z_$][\w$]*)\s*[=(]", logic, re.M)
    dupes = sorted({m for m in members if members.count(m) > 1})
    report(f"class members unique ({len(members)} declared)",
           [f"{d!r} is declared more than once — the later one silently wins" for d in dupes])

    # Any argument list, not just `(s)`. A bag method may legitimately take more — `bagBriefs(s, imcBrief)`
    # does — and requiring a single argument reported it as never spread when it was spread on the very
    # next screen. A lint that raises a phantom failure is worse than no lint: the next real one gets
    # waved through with it.
    bag = re.findall(r"\.\.\.this\.(bag[A-Za-z]+)\s*\(", logic)
    defined = set(re.findall(r"^  (bag[A-Za-z]+)\s*\(", logic, re.M))
    report(f"bag methods composed ({len(bag)} spread in)",
           [f"{b}() is spread into the bag but never defined" for b in bag if b not in defined]
           + [f"{d}() is defined but never spread into the bag" for d in sorted(defined - set(bag))])

    print()
    if fails:
        print(f"{fails} problem(s). This does not prove the file runs, but each of these is real.")
    else:
        print("All checks passed. (Not proof it runs — no JS engine here — but the failure mode "
              "that has actually bitten this project is covered.)")
    return 1 if fails else 0


if __name__ == "__main__":
    raise SystemExit(check(sys.argv[1] if len(sys.argv) > 1 else SRC))
