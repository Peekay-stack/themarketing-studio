The Marketing Studio - handover for Claude Design
=================================================

1. DESIGN.md            The brief. Read this first. It replaces every previous
                        handover document; anything else you have is history.

2. app.dc.html          The file you edit. START FROM THIS COPY, not your local
                        one. It has two changes already in it, both listed in
                        section 1 of DESIGN.md:
                          - demoStrategy now defaults to false
                          - 25 comment banners inserted in the logic
                        Editing your own copy would silently revert both.

3. assets/             The logo artwork that was missing from your project, so the
                        studio lockup renders instead of alt text and the two 404s
                        in your console go away. Goes to api/frontend/assets/.

4. tools/              Optional. Three self-contained Python scripts, standard
                        library only:
                          checkfe.py     the syntax/structure check - run before
                                         any commit that touches app.dc.html
                          partials.py    splits the file into 59 reviewable parts
                                         and rejoins it byte-identically
                          test_tools.py  18 tests proving both of the above
                        Explained in DESIGN.md section 4 and tools/README.md.
                        If you cannot run Python, section 4 is still worth reading
                        - it says which rules are enforced on the backend side.

What I need back is listed in DESIGN.md section 7, in priority order.
Section 8 is the do-not-undo list - 16 items, each one a real bug once.
